<title>Crystal Car Audio | Clear Beats</title>
<div style="margin-top: 11%;" class="server-message">
                <h1 style="font-size: 85px;margin: 0;font-weight: 300;    line-height: 1.1;color:grey;text-align: center;">CyberPanel Installed</h1>
                <h2 style="margin-top: 2%;margin-bottom: 2%;font-weight: 300;    line-height: 1.1;color: #a56565;;text-align: center;">You have successfully installed CyberPanel, please remove this page and upload your website. :)</h2>
                <p style="font-size: 35px;margin: 1%;font-weight: 300;    line-height: 1.1;color:grey;text-align: center;"><a href="http://cyberpanel.net">CyberPanel</a>  <a href="http://forums.cyberpanel.net">Forums</a> <a href="http://docs.cyberpanel.net">Documentation</a></p>
</div>
