<div class="top-notice bg-dark text-white pt-3">
    <div class="container text-center d-flex align-items-center justify-content-center flex-wrap">
        <h4 class="text-uppercase font-weight-bold mr-2">Deal of the week</h4>
        <h6>- 15% OFF in All Performance Parts -</h6>

        <a href="{{url('/')}}" class="ml-2">Shop Now</a>
    </div><!-- End .container -->
</div><!-- End .top-notice -->