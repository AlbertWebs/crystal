@extends('front.master')
@section('content')
<br><br><br>
<center>
<h1>{{$page_title}}</h1>
<br>
<a style="background-color:#1DA098;" href="{{url('/')}}" class="btn btn-large btn-primary">Back to Home</a>
<br> &nbsp; <br>
</center>
@endsection
